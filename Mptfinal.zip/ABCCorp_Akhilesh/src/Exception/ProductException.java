package Exception;

public class ProductException extends Exception {

}
