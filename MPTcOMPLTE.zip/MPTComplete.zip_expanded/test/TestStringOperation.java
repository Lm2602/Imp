import static org.junit.Assert.*;

import org.junit.Test;

public class TestStringOperation {

	@Test
	public void test() {
		fail("Not yet implemented");
		
		
		String exceptionMessage = "Hello, World";
		String actualMessage = new String("Hello, World");
		
	}

}
