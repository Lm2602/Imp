  import static org.junit.Assert.*;
import static org.junit.Assert.fail;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Account;
import com.capgemini.dao.AccountDAO;
import com.capgemini.dao.AccountDAOImpl;

public class TestAccountDAOOperations {
	
	private AccountDAO daoRef;
	
	
	@Before
	public void setup() {
		 System.out.println("Setting up dao object");
		daoRef = new AccountDAOImpl();
		
	}	
	
	//create
	@Test
	public void test() {
		//fail("Not yet implemented");
		Account newAccount= new Account();
		newAccount.setId(10);
		newAccount.setName("Suruchi");
		newAccount.setBalance(1000 );
		
		boolean flag= daoRef.create(newAccount);
		
		
		assertTrue(flag);
		
		newAccount = new Account();
		newAccount.setId(14);
		newAccount.setName("Anjani");
		newAccount.setBalance(10000);
		
		flag=daoRef.create(newAccount);
		
		assertTrue(flag);		
		}
	
	//delete
	@Test
	public void test2()
	{
		boolean flag=daoRef.delete(3);
		assertTrue(flag);
	}
		
	//update
		@Test
		public void test3()
		{
			Account newAccount= new Account();
			newAccount.setId(10);
			newAccount.setName("Anjani");
			newAccount.setBalance(1000 );
			daoRef.create(newAccount);
			
		}
		
		
		//findAll
		
		@Test
		
		public void test4()
		{
		
			
		int a=daoRef.findAll().size();
		assertTrue(a==4);
			
		}
		
		
		//findByAll
		@Test
		
		public void test5()
		{
		
			
		Account a=daoRef.findById(2);
		assertTrue(a.getName().equals("Suhas"));
			
		}
	
		
		//sortFindId
		
		@Test
		
		public void test6() {
			     
		}
	
	
	
	@After
	public void varification() {
		System.out.println("Cleaning up dao object");
		daoRef=null;
	}
	

}
