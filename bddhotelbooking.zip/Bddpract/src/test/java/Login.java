import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Login extends PathPages {
	 private static  String page="login.html";
	 private  static String tittle="";
	 Browser browser;
	public Login(Browser browser) {
		super(page,tittle);
		this.browser=browser;
		PageFactory.initElements(browser.driver, this);
	
	}
	
	@FindBy(how=How.NAME,name="userName")
	private WebElement pfuserName;
	@FindBy(how=How.NAME,name="userPwd")
	private WebElement pfuserPwd;
	@FindBy(how=How.CLASS_NAME, using="btn")
	private WebElement pfbtn;

	public WebElement getPfuserName() {
		return pfuserName;
	}
	public void setPfuserName(String pfuserName) {
		this.pfuserName.sendKeys(pfuserName);;
	}
	public WebElement getPfuserPwd() {
		return pfuserPwd;
	}
	public void setPfuserPwd(String pfuserPwd) {
		this.pfuserPwd.sendKeys(pfuserPwd);;
	}
	public WebElement getPfbtn() {
		return pfbtn;
	}
	public void setPfbtn() {
		pfbtn.click();
	}
	

}
