$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/awesome.feature");
formatter.feature({
  "name": "awesome",
  "description": " In order to avoid silly mistakes\n As a math idiot\n I want to be told the sum of two numbers",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "name": "Title of your scenario",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.step({
  "name": "I have entered 50 into the calculater",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefs.I_have_entered_into_the_calculater(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I have entered 70 into the calculater",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefs.I_have_entered_into_the_calculater(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I press add",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefs.I_press_add()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the result should be 120 on the screen",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefs.the_result_should_be_on_the_screen(int)"
});
formatter.result({
  "status": "passed"
});
});