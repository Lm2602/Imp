import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDefs {
	private int[]nos = new int[2];
	private int count;
	private int result;

	@Given("^I have entered (\\d+) into the calculater$")
	public void I_have_entered_into_the_calculater(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//		TODO	CREATE A WEBDRIVER HERE
//		TODO NAVIGATING TO THE PAGE
	   // throw new PendingException();
		nos[count++] = arg1;

	}


	@When("^I press add$")
	public void I_press_add() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
//		TODO:	WRITE A SELENIUM SCRIPT TO SIMULATE USER ACTIONS
	    //throw new PendingException();
		result = nos[0]+nos[1];
	
	}
	
	@Then("^the result should be (\\d+) on the screen$")
	public void the_result_should_be_on_the_screen(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//		TODO: 	ASSERTING WHETHER THOSE ACTIONS WERE SUCCESSFUL OR NOT
	   // throw new PendingException();
		Assert.assertEquals(arg1, result);
	}
	
	
}
