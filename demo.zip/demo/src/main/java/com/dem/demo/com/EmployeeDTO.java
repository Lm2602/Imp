package com.dem.demo.com;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class EmployeeDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "ID")
	private Integer id;
	@Column(name = "NAME")
	private String name;
	
	@Column(name="AGE")
	private int age;

	@Column(name="POST")
	private String post;
	
	
	public EmployeeDTO(Integer id, String name, int age, String post) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.post = post;
	}
	
	
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getPost() {
		return post;
	}


	public void setPost(String post) {
		this.post = post;
	}

}
