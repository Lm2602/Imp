package com.dem.demo.com.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import com.dem.demo.com.EmployeeDTO;
import com.dem.demo.com.dto.EmployeeDAO;

@Repository
@Transactional
public class JPAEmployee implements EmployeeDAO{
	
@PersistenceContext
private EntityManager entityManager;


	@Override
	public List<EmployeeDTO> findAll() {
		// TODO Auto-generated method stub
		Query query = entityManager.createQuery(
				"select e from EmployeeDTO e");
		return null; 
				//return query.getResultList();
	
	}

	@Override
	public EmployeeDTO findById(int id) {
		// TODO Auto-generated method stub
		return (EmployeeDTO)entityManager.find(EmployeeDTO.class, id);
	}

	@Override
	public EmployeeDTO create(EmployeeDTO Employee) {
		// TODO Auto-generated method stub
		//System.out.println("putting data");
		entityManager.persist(Employee);
		
		return Employee;
	}

	@Override
	public EmployeeDTO update(EmployeeDTO Employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeDTO delete(int id) {
		// TODO Auto-generated method stub
		EmployeeDTO s=(EmployeeDTO)entityManager.find(EmployeeDTO.class, id);
		entityManager.remove(s);
		return s;
	}

}
