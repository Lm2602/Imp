package com.dem.demo.com.dto;

import java.util.List;

import com.dem.demo.com.EmployeeDTO;
public interface EmployeeDAO {

	 public List<EmployeeDTO> findAll(); 
	    public EmployeeDTO findById(int id);
	    public EmployeeDTO create(EmployeeDTO Employee);
	    public EmployeeDTO update(EmployeeDTO Employee);
	    public EmployeeDTO delete(int id);
}
