package com.demo.ControllerHelper;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.dem.demo.com.EmployeeDTO;
import com.dem.demo.com.dto.EmployeeDAO;

@RestController
@RequestMapping("/controller")
public class EmployeeActionsControllerHelper {
		@Autowired
		private EmployeeDAO employeeDAORef;

		@RequestMapping(method=RequestMethod.GET,value="car")
		public List<EmployeeDTO> list()
		{    
			System.out.println("welcome");
			return employeeDAORef.findAll();
		}
		
		@RequestMapping(method=RequestMethod.POST, value="Employee")
		public EmployeeDTO save(@RequestBody EmployeeDTO Employee)
		{
			return employeeDAORef.create(Employee);
		}
		
		@RequestMapping(method=RequestMethod.GET, value="Employee/{id}")
		public EmployeeDTO get(@PathVariable(name="id") int id)
		{
			return employeeDAORef.findById(id);
		}
		
		@RequestMapping(method=RequestMethod.PUT, value="Employee/{id}")
		public EmployeeDTO update(@RequestBody EmployeeDTO Employee,@PathVariable(name="id") int id)
		{
			return employeeDAORef.update(Employee);
		}

		@RequestMapping(method=RequestMethod.DELETE, value="Employee/{id}")
		public EmployeeDTO delete(@PathVariable(name="id") int id)
		{
			return employeeDAORef.delete(id);
		}

	}
