import static org.junit.Assert.*;

import java.time.format.DateTimeFormatter;

import javax.swing.text.DateFormatter;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.SaleDAO;

public class testcase {
	
	private SaleDAO daoref;
	@Before
	public void setup()
	{
		
 daoref = new SaleDAO();
	}

	@Test
	public void test() {
		Sale a = daoref.abd(1004);
		assertTrue(a.getProductName().equals(""));
		
	}

	
	
	@After
	public void finish()
	{
		
 daoref = null;
	}
	
	
}
