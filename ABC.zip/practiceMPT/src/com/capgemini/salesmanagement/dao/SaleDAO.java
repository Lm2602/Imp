package com.capgemini.salesmanagement.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class SaleDAO implements ISaleDAO {
	HashMap<Integer, Sale> hmap;

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		hmap = CollectionUtil.getCollection();
		hmap.put(sale.getProdCode(), sale);
		return hmap;

	}

	public Sale abd(int prodCode) {
		int check;
		for (Entry<Integer, Sale> x : hmap.entrySet())

		{
			check = x.getValue().getProdCode();
			if (check == prodCode) {

				return x.getValue();
			}
		}

		return null;

	}

}
