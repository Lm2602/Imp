package com.capgemini.salesmanagement.ui;

import java.time.LocalDate;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.service.SaleService;

import Exception.IOException;

public class Client {
	public static void main(String[] args) throws IOException {
		int r=(int) (100+Math.random());
	//	int d = Integer.parseInt(r);
		Scanner s = new Scanner(System.in);
	
		SaleService service = new SaleService();
		
	    System.out.println("enter the product code");
		int code = Integer.parseInt(s.nextLine());
		boolean flag=service.validateProductCode(code);
		if(flag==false)
		{
			System.out.println("invalid");
		   throw new IOException("not found");
		}
		System.out.println("enter the quantity");
		int qty = Integer.parseInt(s.nextLine());
		boolean flag1=service.validateQuantity(qty);
		if(flag1==false)
		{
			System.out.println("invalid");
			System.exit(0);
		}
		
		System.out.println("product category");
		String cat = s.nextLine();
		boolean flag2=service.validateProductCat(cat);
		if(flag2==false)
		{
			System.out.println("invalid");
			System.exit(0);
		}
		System.out.println("product name");
	    /*s.nextLine();*/
		String pname = s.nextLine();
	
		boolean flag3=service.validateProductName(pname);
		if(flag3==false)
		{
			System.out.println("invalid");
			System.exit(0);
		}
		System.out.println("product Description");
		String pdes = s.next();
		
		System.out.println("product Price");
		int pric = s.nextInt();
		boolean flag4=service.validateProductPrice(pric);
		if(flag4==false)
		{
			System.out.println("invalid");
			System.exit(0);
		}
		
		
		Sale sale=new Sale();
		LocalDate dt=LocalDate.now();
		sale.setSaleId(r);
		sale.setCategory(cat);
		sale.setProdCode(code);
        sale.setProductName(pname);
        sale.setLineTotal(pric*qty);
		sale.setQuantity(qty);
		sale.setSaleDate(dt);
		
		System.out.println("Line total(Rs)"+pric*qty);
		System.out.println("Quantity= "+qty);
		Map<Integer,Sale> salemap=service.insertDetails(sale);
		
		for(Map.Entry<Integer,Sale> var:salemap.entrySet() )
		{
			System.out.println("Product name: "+var.getValue().getProductName());
			System.out.println("Product code: "+var.getValue().getProdCode());
			System.out.println("Product category: "+var.getValue().getCategory());
			
			
		}
		
		
	
	

	}

	
	

}
