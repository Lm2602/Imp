package com.cg.dao.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;

public class InMemoryCarDao implements CarDAO {

	Map<Integer, CarDTO> carRef = new HashMap<Integer, CarDTO>();

	@Override
	public void create(CarDTO car) {
		// TODO Auto-generated method stub

		carRef.put(car.getId(), car);
	}

	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub
		for (String s : ids) {
				carRef.remove(Integer.parseInt(s));

		}

	}
	@Override
	public List<CarDTO> findAll() {
		// TODO Auto-generated method stub
		List<CarDTO> listRef = new LinkedList<CarDTO>(carRef.values());

		return listRef;
	}

	@Override
	public CarDTO findById(int id) {
		if (carRef.containsKey(id)) {
			return (CarDTO) carRef.values();
		} else
			return null;
	}

	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		//if (carRef.containsKey(car.getId())) {

			carRef.put(car.getId(), car);
	//	}

	}

}
